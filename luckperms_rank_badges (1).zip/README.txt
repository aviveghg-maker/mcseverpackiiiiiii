LuckPerms Rank Badges

Individual PNG badges with transparent background.
Ranks: OWNER, SR_DEV, DEV, SR_ADMIN, ADMIN, SR_MOD, MOD, HELPER, BUILDER, VIP

Use each PNG as a visual badge asset. These are image files, not a ready-to-install Minecraft resource pack; integration depends on your chat/tab plugin.
